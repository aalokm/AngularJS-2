/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { UsersComponent } from './users.component';

describe('Component: Users', () => {
  it('should create an instance', () => {
    let component = new UsersComponent();
    expect(component).toBeTruthy();
  });
});
