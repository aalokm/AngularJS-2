# TutorialNg2RestService

Sources for the tutorial "Angular2 tutorial: Building a simple REST call with service, observable and view", which can be found here: https://niedermeier.io/2017/04/12/tutorial-ng2-rest-service/
