"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var EmployeeModel = (function () {
    function EmployeeModel() {
    }
    return EmployeeModel;
}());
exports.EmployeeModel = EmployeeModel;
//# sourceMappingURL=EmployeeModel.js.map