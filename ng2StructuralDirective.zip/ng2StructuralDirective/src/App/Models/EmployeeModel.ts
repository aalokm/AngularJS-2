export class EmployeeModel{
    public EmployeeID:number;
    public FirstName:string;
    public LastName:string;
    public ContactNo:string;
    public Designation:string;
}