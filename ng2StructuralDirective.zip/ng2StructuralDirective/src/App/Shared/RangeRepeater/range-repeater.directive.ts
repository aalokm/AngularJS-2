import {Directive, TemplateRef, ViewContainerRef, Input} from '@angular/core';
@Directive({
    selector:'[rangeRepeater]'
})
export class RangeRepeaterDirective{
    constructor(private templateRef: TemplateRef<any>,
                private viewContainerRef: ViewContainerRef){

    }

    @Input()
    set rangeRepeater(value){        
        this.viewContainerRef.clear();
        for(var i:number=value[0]; i<= value[1]; i++){
            this.viewContainerRef.createEmbeddedView(this.templateRef,{
                $implicit: i
            })
        }
    }
}