import {Component, OnInit} from '@angular/core'
import {EmployeeModel} from '../Models/EmployeeModel'
@Component({
    selector:'employee-list',
    templateUrl:'employee-list.component.html',
    moduleId: module.id
})
export class EmployeeListComponent implements OnInit{
    public EmployeeList: Array<EmployeeModel> = [];
    
    private pageSize:number = 2;
    public TotalPage:number =1; 
    public curerntPage: number=1;

    public LoadIntialData(filterText:string):void{
        this.EmployeeList = [{
            EmployeeID:1,
            FirstName: "Sourav",
            LastName:"Mondal",
            ContactNo: "1234567890",
            Designation:"Software Developer"
        },
        {
            EmployeeID:2,
            FirstName: "Rik",
            LastName:"Decosta",
            ContactNo: "1478523690",
            Designation:"Software Developer"
        },{
            EmployeeID:3,
            FirstName: "Jhon",
            LastName:"Decosta",
            ContactNo: "5874213690",
            Designation:"Software Developer"
        }];

        if(filterText !=""){
            var afterFilterEmpList: Array<EmployeeModel> = [];
            this.EmployeeList.forEach(item=>{
                if(item.FirstName.toLowerCase().includes(filterText) ||
                item.LastName.toLowerCase().includes(filterText))
                {
                    afterFilterEmpList.push(item);
                }
            })
            this.EmployeeList = afterFilterEmpList;
        }
        this.TotalPage = (this.EmployeeList.length / this.pageSize) +
                        ((this.EmployeeList.length % this.pageSize)>0?1:0);
    }
    ngOnInit(){
        this.LoadIntialData("");  
        setTimeout(()=> {
            this.EmployeeList.push({
                EmployeeID:4,
                FirstName: 'Riki',
                LastName:'Roy',
                ContactNo: '1245789632',
                Designation: 'HR'
            });
        }, 5000);
    }
    OnEmployeeSearch(searchText):void{
        this.LoadIntialData(searchText);            
    }    
    setPage(page):void{
        this.curerntPage = page;
    }
}