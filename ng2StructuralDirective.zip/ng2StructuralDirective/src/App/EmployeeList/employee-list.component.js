"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var EmployeeListComponent = (function () {
    function EmployeeListComponent() {
        this.EmployeeList = [];
        this.pageSize = 2;
        this.TotalPage = 1;
        this.curerntPage = 1;
    }
    EmployeeListComponent.prototype.LoadIntialData = function (filterText) {
        this.EmployeeList = [{
                EmployeeID: 1,
                FirstName: "Sourav",
                LastName: "Mondal",
                ContactNo: "1234567890",
                Designation: "Software Developer"
            },
            {
                EmployeeID: 2,
                FirstName: "Rik",
                LastName: "Decosta",
                ContactNo: "1478523690",
                Designation: "Software Developer"
            }, {
                EmployeeID: 3,
                FirstName: "Jhon",
                LastName: "Decosta",
                ContactNo: "5874213690",
                Designation: "Software Developer"
            }];
        if (filterText != "") {
            var afterFilterEmpList = [];
            this.EmployeeList.forEach(function (item) {
                if (item.FirstName.toLowerCase().includes(filterText) ||
                    item.LastName.toLowerCase().includes(filterText)) {
                    afterFilterEmpList.push(item);
                }
            });
            this.EmployeeList = afterFilterEmpList;
        }
        this.TotalPage = (this.EmployeeList.length / this.pageSize) +
            ((this.EmployeeList.length % this.pageSize) > 0 ? 1 : 0);
    };
    EmployeeListComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.LoadIntialData("");
        setTimeout(function () {
            _this.EmployeeList.push({
                EmployeeID: 4,
                FirstName: 'Riki',
                LastName: 'Roy',
                ContactNo: '1245789632',
                Designation: 'HR'
            });
        }, 5000);
    };
    EmployeeListComponent.prototype.OnEmployeeSearch = function (searchText) {
        this.LoadIntialData(searchText);
    };
    EmployeeListComponent.prototype.setPage = function (page) {
        this.curerntPage = page;
    };
    return EmployeeListComponent;
}());
EmployeeListComponent = __decorate([
    core_1.Component({
        selector: 'employee-list',
        templateUrl: 'employee-list.component.html',
        moduleId: module.id
    })
], EmployeeListComponent);
exports.EmployeeListComponent = EmployeeListComponent;
//# sourceMappingURL=employee-list.component.js.map